# Annual Web Hosting

**Code:** CMWBW2 · https://www.divstrong.com/proposal/CMWBW2  
**Client:** Chad White · Winners Circle Awards · chad@winnerscircleprint.com · www.winnerscircleprint.com/  
**Status:** converted (accepted 2026-10-02 11:41:51)  
**Date:** 2026-09-22 · valid until 2026-10-31  
**Total:** $360.00

## Overview

Our goal is to enhance the existing PromoSoft instance with a communications feature that will allow conversations to take place across orders, employees, and groups where they can share messages, files, links, and relevant information via a pop-out panel accessible from any view within the instance.

## Scope of Work

### Hosting

**Cloud Hosting > Annual Term** — Annual hosting of the website @ https://www.winnerscircleprint.com/ effective 10/1/26 - 9/30/27
- Cloud infrastructure provisioning, configuration, and deployment pipeline setup.
- Routine platform updates, security patches, and performance monitoring
- SSL certificate included, with automatic renewal and HTTPS enforcement
- Automated daily backups with offsite retention and one-click restore
- Site deployment, content migration + brand customization included

## Investment

Hosting term effective 10/1/26 - 9/30/27

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Hosting > Annual Term @ www.winnerscircleprint.com | 12 | $30.00 | $360.00 |
| **Total** | | | **$360.00** |

## Payment Milestones

- 100% ($360.00) — to engage site migration + hosting

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $100/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.

**Signed by:** Chad White
