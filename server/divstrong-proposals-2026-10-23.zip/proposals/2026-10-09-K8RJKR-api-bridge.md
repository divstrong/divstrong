# API Bridge

**Code:** K8RJKR · https://www.divstrong.com/proposal/K8RJKR  
**Client:** Warren McCrickard · warren.mccrickard@btmva.org · www.btmva.org  
**Status:** converted (accepted 2026-10-23 08:02:17)  
**Date:** 2026-10-09 · valid until 2026-10-31  
**Total:** $4,610.00

## Scope of Work

### Development

**Web Application Build > API Bridge + Management Portal** — Development of a custom, cloud-based, secure web portal that provide management and visualization of Quickbooks and Bloomerang data pulled in via API to ensure it is synced + stored properly.
- ‘Dashboard’ view that provides import + sync buttons to pull from API sources and a compare view for matching
- ‘Donors’ view to search/filter/manage all donor data merged from API sources
- ‘Transactions’ view to search/filter/manage all payments/deposits merged from API sources
- ‘Settings’ view to manage general contact information and related organization data
- ‘Users’ view to search/filter/manage all admin users and their account data + roles/permissions
- Quickbooks API integration for pulling donor/donation related data
- Bloomerang API integration for pushing/pulling donor related data

**Web Development > Chart of Accounts** — Enhancing the custom web portal with a Chart of Accounts reporting and labeling tool to classify donors and donations by funding source including exports.
- Create and manage classifications for donation sources, including individuals, companies, foundations, government agencies, and other organizations, with optional account codes and subcategories.
- Assign classifications to each donor and apply it automatically to new donations, with the ability to override the classification for individual transactions.
- Reporting tools to summarize donation totals, donation counts, average donation amounts, and percentage of overall funding by classification.
- Export summary reports and detailed donation records to CSV, Excel (XLS/XLSX), and PDF with date ranges

### Hosting

**Annual Cloud Hosting** — Cloud infrastructure provisioning, configuration, and deployment pipeline setup, with ongoing server maintenance included in the annual hosting fee @ app.btmva.org (or similar domain)
- SSL certificate installation and automatic renewal
- 24/7 uptime monitoring with prompt incident response
- Regular server and software security patches and updates

## Investment

Effort to be completed within three (3) weeks of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Web Development Sprint > API Bridge | 1 | $3,000.00 | $3,000.00 |
| Web Development > Chart of Accoutns | 1 | $1,250.00 | $1,250.00 |
| Hosting > Annual Term | 12 | $30.00 | $360.00 |
| **Total** | | | **$4,610.00** |

## Payment Milestones

- 50% ($2,305.00) — Initial deposit to engage project
- 50% ($2,305.00) — Final payment upon project completion, prior to launch

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
10. All work product created by divStrong for Client, including but not limited to code, designs, graphics and content, shall become the sole property of Client upon successful completion of the project scope and receipt of full payment as outlined in this Agreement.

**Signed by:** Warren J McCrickard
