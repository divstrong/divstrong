# Zoning Document Management

**Code:** FGBNFF · https://www.divstrong.com/proposal/FGBNFF  
**Client:** Jay Litten · Town of Bridgewater · jjlitten@bridgewater.town · www.bridgewater.town  
**Status:** viewed  
**Date:** 2026-02-23 · valid until 2026-03-31  
**Total:** $3,400.00

## Overview

Our aim is to enhance the existing custom web application @ luma.bridgewater.town with additional features for managing zoning records in the Town of Bridgewater including a parsing tool that will take data from forwarded emails and assign to various households + citizens.

## Scope of Work

### Development

**Web Application Enhancements** — Enhancing the existing custom web application @ luma.bridgewater.town with the following features:
- New 'Official Log' resource that will allow for management of significant documents to be stored with households and a tax parcel #
- Custom view for each tax parcel # to easily review/access stored documents and related data
- Development of a webhook to serve as a 'parser' email address that will use a defined pattern to store related/attached information with the noted tax parcel #
- Activity tracking to note who created each record + timestamp
- Implementation of an address validation tool such as Google Places, USPS, or similar

### Quality Assurance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server
- Miscellaneous minor change requests expected throughout the build

## Investment

Project to be completed within four (4) weeks of start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Web Application Development | 24 | $125.00 | $3,000.00 |
| QA/Testing | 4 | $100.00 | $400.00 |
| **Total** | | | **$3,400.00** |

## Payment Milestones

- 50% ($1,700.00) — initial deposit to engage project
- 50% ($1,700.00) — due upon project delivery + completion

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $125/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
