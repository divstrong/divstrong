# ZOOM Integration + Workshop Enhancements

**Code:** JSA7AU · https://www.divstrong.com/proposal/JSA7AU  
**Client:** Joe Manriquez · Golightly Law · joe@golightlylaw.com · golightlylaw.com/  
**Status:** viewed  
**Date:** 2026-06-10 · valid until 2026-06-30  
**Total:** $1,925.00

## Scope of Work

### Development

**Web Development > ZOOM Integration + Workshop Forms**
- Updating Webflow content for storage of ZOOM link with workshop data for sharing with registrants
- Building out the Workshop Registration form to accept registrations from client that will send them an email confirmation + calendar invite to join session
- Submission of data to CLIO Grow after first validating a duplicate lead does not already exist

**Web Development > Ebook Automation + CLIO**
- Capturing lead data from eBook conversion form into CLIO Grow, validating lead is not a duplicate
- Email confirmation  will be sent to user with branded aesthetic including a direct link to download the Ebook
- Automated follow-up email sent at 12PM the following day after downloading eBook with custom message pertaining to either Elder Care or Estate Planning

### Maintenance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server
- Minor change requests TBD during project lifecycle

## Investment

Effort to be completed within two weeks of project start date

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Development > ZOOM Integration + Workshop Forms | 8 | $125.00 | $1,000.00 |
| Development > Ebook Automation + CLIO  | 5 | $125.00 | $625.00 |
| QA/Testing | 3 | $100.00 | $300.00 |
| **Total** | | | **$1,925.00** |

## Payment Milestones

- 50% ($962.50) — due to engage project
- 50% ($962.50) — due upon project completion

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
