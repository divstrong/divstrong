# Riverside Logistics Custom TMS

**Code:** BVACFG · https://www.divstrong.com/proposal/BVACFG  
**Client:** Shawn Greenwood · Riverside Logistics · sgreenwood@riversidelogistics.com · www.riversidelogistics.com  
**Status:** draft  
**Date:** 2026-10-23 · valid until 2026-11-30  
**Total:** $34,500.00

## Overview

Your organization is converting Pocahontas Parkway to All-Electronic Tolling with a cutover targeted for July 1, 2027, and the RFP is explicit that customer-facing communication is one of the principal levers available to move drivers up the conversion funnel — Tier 1 E-ZPass, Tier 2 third-party apps, Tier 3 pay-by-plate — and away from the violator outcome. Equally explicit are the operational demands behind that campaign: a daily dashboard during the launch window covering web traffic, social engagement, Back Office call volumes by topic, complaint sentiment and E-ZPass enrollment counts; weekly written reporting pre-launch and at launch, shifting to monthly during stabilization; numerical KPI targets against a 7.5M-transaction baseline and a 75/13/3/9 payment mix moving toward 85% E-ZPass, 8% pay-by-plate and 7% violators; an attribution approach that has to be invented, because no end-to-end mechanism exists today with the Virginia E-ZPass program or with GoToll, Uproad, NextPass and Peasy. You also need an interactive "Which payment method is right for me?" decision tool, an AET transition page and updated Payment Methods page, and a permanent scam-awareness module on the Parkway site.

divStrong is responding as the technology partner inside a combined team: our marketing agency partner owns strategy, research, brand, creative, paid and earned media, content and stakeholder outreach, while divStrong owns the software — the decision tool, the campaign measurement dashboard, the data source and API integrations to the Back Office System and customer-service platform, the attribution instrumentation, and the scam-monitoring and alerting plumbing that sits under the rapid-response protocol. We deliver that in four two-week sprints at a fixed $3,000 each. Each sprint has a named theme, a bounded scope, and deliverables that are handed over — working software, documented endpoints, a published tool — not activity reports. That cadence gives your team a predictable review point every fourteen days and a clear place to trade scope before anything drifts.

Our team is made up of veteran technologists who have built measurement and integration layers for operators who cannot afford a surprise at go-live, and this project has the profile we do our best work on: real baseline numbers, a hard cutover date, a funnel that can actually be instrumented, and a client that has already thought carefully about what "unexpected bill" costs in call volume and goodwill. We are genuinely excited to build the tool that answers a driver's question in thirty seconds and the dashboard that tells your team, every morning during launch, whether the campaign is working.

## Scope of Work

### Strategy

**Consulting + Planning** — Standing meeting(s) with relevant client staff to obtain direction, feedback and provide recommendations on all application development initiatives throughout the life of the project
- Weekly review of functional sprint progress and overall project status
- Prioritization of project backlog to focus each sprint in accordance with client goals

### Sprint #1 — Discovery And Foundation

**Workflow And Acceptance Plan** — We walk through how your team books, dispatches, and bills loads today and agree, in writing, what each later sprint delivers and how you will judge it done.
- Documented workflows for booking, dispatch, documents, and billing
- Acceptance criteria for every sprint, agreed before build starts
- Confirmed list of vendor accounts and API access needed for later sprints

**Roles, Permissions And Data Ownership** — Everyone gets the access their job needs and nothing more, and it is clear who owns each kind of record from day one.
- Agreed role list with what each role can view, edit, and approve
- Data ownership map covering customers, carriers, loads, and financials
- Working sign-in with role-based access in place

**Load Plus Assessment And Audit History** — We review what your Load Plus exports contain and how they map across, and we switch on an audit trail so every change in the new platform is recorded from the start.
- Load Plus import assessment with a field-by-field mapping
- Sample import run on a copy of your data, with findings
- Audit history recording who changed what, and when

### Sprint #2 — Customers And Contacts

**Customer Records And Locations** — Each customer has one record holding everything about them, including every location you pick up from or deliver to on their behalf.
- Customer record with company details and notes
- Multiple locations per customer with addresses and hours
- Search and filter across all customers

**Contacts And Billing Preferences** — Every person you deal with at a customer is on file with their role, and billing goes to the right place in the right way every time.
- Multiple contacts per customer, each with a role and contact details
- Billing preferences per customer, including invoice recipients
- Credit settings with limits visible to the people booking loads

**Customer Load Defaults** — The details a customer always wants are filled in for you, so repeat loads take less typing and fewer mistakes.
- Customer-specific defaults applied when a new load is started
- Defaults editable per customer by permitted roles
- Clear indication on the load of which values came from defaults

### Sprint #3 — Carrier Management

**Carrier Records And Identifiers** — Every carrier you work with has one record, keyed on the identifiers your team already uses to look them up.
- Carrier record with company and contact details
- MC and DOT numbers stored and searchable
- Insurance and authority fields with expiry dates

**Preferred And Blocked Carriers** — Your team can see at a glance who you prefer to use and who you never use, along with the notes that explain why.
- Preferred and blocked status on each carrier
- Priority notes shown wherever the carrier is selected
- History of status changes with who made them

**Booking Restriction Rules** — The platform stops a load being booked with a carrier that should not have it, instead of relying on someone to remember.
- Booking rules covering blocked status, insurance, and authority
- Clear warning explaining why a carrier cannot be booked
- Rules configurable by permitted roles

### Sprint #4 — Pre-Load And Load Building

**Load Details And Equipment** — Everything a carrier needs to know about the freight is captured once, in a consistent shape, before the load goes anywhere.
- Equipment type and refrigeration requirements
- Cargo description, weight, and dimensions
- PO and reference numbers attached to the load

**Stops And Appointments** — A load can carry as many pickups and deliveries as it needs, each with its own appointment, in the order the truck will run them.
- Multiple stops per load, reorderable
- Appointment date and time window for each stop
- Stop-level references and instructions

**Templates And Load Duplication** — Lanes you run again and again become one-click starts, so your team builds repeat freight in seconds.
- Saved load templates for recurring lanes
- Duplicate any historical load as the start of a new one
- Duplicated loads clearly marked as new until saved

### Sprint #5 — Dispatch And Booking

**Dispatch Board** — One screen shows every active load and where it stands, so dispatchers know what needs attention without asking around.
- Dispatch board with filters by status, date, and dispatcher
- Status workflow from booked through delivered
- Load detail available from the board in one click

**Carrier, Driver And Dispatcher Assignment** — Each load clearly shows which carrier, driver, and dispatcher own it, and hand-offs between dispatchers are recorded.
- Carrier and driver assignment on each load
- Dispatcher ownership with reassignment
- Assignment history on the load

**Booking Checks And Recorded Overrides** — The platform checks each booking against your rules before it is confirmed. When someone has a good reason to proceed anyway, their override is permitted, recorded, and visible.
- Booking checks with warnings shown before confirmation
- Permission-controlled overrides with a required reason
- Override log showing who overrode what, and why

### Sprint #6 — Rates And Commissions

**Rate Tables And Supporting Uploads** — Customer rates and carrier costs live in the platform with the paperwork that backs them up, instead of in spreadsheets and inboxes.
- Rate tables for customer revenue and carrier costs
- Supporting documents uploaded against rates
- Accessorial charges added to customer and carrier sides

**Margin Visibility** — Every load shows what it earns before and after it is booked, so nobody finds a thin load at month end.
- Margin calculated per load from revenue, costs, and accessorials
- Margin shown on the load and on the dispatch board
- Pricing amendments recorded with the change and who made it

**Commission Allocations** — When more than one person earns on a load, the split is set on the load itself and carries through to reporting.
- Multiple commission allocations per load
- Allocation rules by percentage or amount
- Commission figures available for reporting

### Sprint #7 — Documents And Acceptance

**BOLs, Rate Confirmations And Agreements** — The documents every load needs are generated from the load itself, so the details always match what was booked.
- Bill of lading generated from the load
- Rate confirmations and agreements generated from the load
- Email and print straight from the load

**Secure Carrier Acceptance** — Carriers review and accept a rate confirmation on a secure page and fill in their driver details there, so nothing has to be keyed in twice.
- Secure acceptance page for each rate confirmation
- Driver details, seal number, and PRO number captured on acceptance
- Acceptance recorded on the load with date and time

**Document Versions And POD Uploads** — Every version of every document is kept, and proof of delivery lands on the load as soon as it arrives.
- Document version history on each load
- POD upload attached to the load
- Loads missing a POD flagged for follow-up

### Sprint #8 — Tracking Integrations

**Tracking Provider Connections** — We connect the tracking functions you need from Trucker Tools, MacroPoint, and Samsara, so location updates arrive on the load without anyone copying them across.
- Agreed functions connected for Trucker Tools, MacroPoint, and Samsara
- Tracking provider selected per load
- Connection status visible to dispatchers

**Location And Milestone Updates** — Each load builds its own timeline of where the truck was and when it reached each stop.
- Location updates stored with timestamps
- Stop milestones updated from tracking data
- Tracking timeline on the load

**Tracking Exceptions** — When tracking goes quiet or a truck is running late, the load is flagged so someone can act before the customer calls.
- Exception rules for missed updates and late arrivals
- Exceptions surfaced on the dispatch board
- Exception history recorded on the load

### Sprint #9 — Carrier-Service Integrations

**Highway, MyCarrierPackets And RMIS Connections** — We connect the carrier-service functions you rely on, so verification and onboarding information is in the platform rather than in separate tabs.
- Agreed functions connected for Highway, MyCarrierPackets, and RMIS
- Connection status and last sync time visible on the carrier
- Errors from each service logged and surfaced

**Carrier Matching And Verification Status** — Results from each service are matched to the right carrier record and shown where your team makes booking decisions.
- Carrier matching against MC and DOT numbers
- Onboarding and verification status on each carrier
- Mismatches flagged for review

**Operational Controls** — Verification results feed straight into the booking rules from Sprint 3, so an unverified carrier is caught at the point of booking.
- Booking rules extended with verification results
- Warnings when a carrier's status changes
- Controls configurable by permitted roles

### Sprint #10 — Accounting Integration

**Sage 50 Data Exchange** — Customer and financial data moves between the platform and Sage 50 in the ways agreed during discovery, without re-keying.
- Agreed customer data exchange with Sage 50
- Agreed financial data exchange with Sage 50
- Sync history showing what moved and when

**Invoice-Ready Handoff And Credit Visibility** — Delivered loads are handed to accounting ready to invoice, and the people booking loads can see a customer's credit position.
- Invoice-ready handoff for delivered loads
- Customer credit position visible when booking
- Loads held from handoff until required documents are in

**Reconciliation And Sync Errors** — When the two systems disagree, someone is told, and the discrepancy can be worked through rather than discovered later.
- Reconciliation view comparing platform and Sage 50 figures
- Sync errors logged with a clear reason
- Retry for failed syncs once the cause is fixed

### Sprint #11 — Reporting And Automation

**Operational And Financial Dashboards** — Managers see how the business is running today and how it is performing financially, from data that is already in the platform.
- Operational dashboard covering active loads and exceptions
- Financial dashboard covering revenue, costs, margin, and commissions
- Date and team filters on both dashboards

**Priority Notes And Activity-Triggered Emails** — The right people hear about the right things automatically, from a load that needs attention to a step that has just been completed.
- Priority notes and exceptions summarized for each team
- Activity-triggered emails for agreed events
- Email rules editable by permitted roles

**DAT Posting** — If DAT stays in the agreed scope, loads can be posted, updated, and removed on DAT from the load itself.
- Post, update, and remove loads on DAT from the platform
- DAT posting status visible on the load
- Confirmed during discovery whether DAT remains in scope

### Sprint #12 — Pilot And Launch

**Final Migration And End-To-End Testing** — Your live data comes across from Load Plus, and we run real loads through every step together before anyone relies on the new platform.
- Final data migration from Load Plus
- End-to-end test of booking, dispatch, documents, tracking, and accounting
- Test results recorded against the acceptance criteria from Sprint 1

**Client Acceptance And Corrections** — Your team signs off against the criteria agreed at the start, and anything that falls short is corrected before launch.
- Acceptance session with your team
- Corrections made and re-tested
- Written sign-off

**Training, Cutover And Launch Verification** — Your team is trained on the platform they will use every day, the switch from Load Plus happens on a planned date, and we confirm everything is working once it is live.
- Role-based training sessions for your team
- Planned cutover from Load Plus
- Post-launch verification checks

## Investment

Project to be completed within six (6) months effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Sprint #1 - Strategy + Planning | 1 | $3,000.00 | $3,000.00 |
| Sprint #2 - Cloud Platform + API | 1 | $3,000.00 | $3,000.00 |
| Sprint #3 — Dashboard + Integrations | 1 | $3,000.00 | $3,000.00 |
| Sprint #4 - Crisis Communications Tool | 1 | $3,000.00 | $3,000.00 |
| Sprint #5 - Email + SMS Marketing Tool | 1 | $3,000.00 | $3,000.00 |
| Sprint #6 - Email + SMS Marketing Tool | 1 | $3,000.00 | $3,000.00 |
| Sprint #8 - Email + SMS Marketing Tool | 1 | $3,000.00 | $3,000.00 |
| Sprint #9 - Email + SMS Marketing Tool | 1 | $3,000.00 | $3,000.00 |
| Sprint #10 - Email + SMS Marketing Tool | 1 | $3,000.00 | $3,000.00 |
| Sprint #11 - Email + SMS Marketing Tool | 1 | $3,000.00 | $3,000.00 |
| Sprint #12 - Email + SMS Marketing Tool | 1 | $3,000.00 | $3,000.00 |
| Hosting - Annual Term | 12 | $125.00 | $1,500.00 |
| **Total** | | | **$34,500.00** |

## Payment Milestones

- 25% ($8,625.00) — due to engage project
- 25% ($8,625.00) — due thirty (30) days following project start date
- 25% ($8,625.00) — due thirty (60) days following project start date
- 25% ($8,625.00) — due thirty (90) days following project start date

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
