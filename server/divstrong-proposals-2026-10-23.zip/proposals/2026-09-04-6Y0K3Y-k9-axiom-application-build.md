# K9 Axiom Application Build

**Code:** 6Y0K3Y · https://www.divstrong.com/proposal/6Y0K3Y  
**Client:** Ryan Leach · Fresh Move Media · ryan@freshmovemedia.com · www.freshmovemedia.com  
**Status:** draft  
**Date:** 2026-09-04 · valid until 2026-10-15  
**Total:** $23,600.00

## Overview

We aim is to deliver a full stack web application that will serve as the backend and administration portal for a native application that will connect Mahjong players with the goal of connecting + playing the game in person at the host venue. Free trials will be offered to new members who will then play a subscription fee to continue using the platform which will be built in a scalable fashion to allow for adding features as the ecosystem expands.

One additional sprint has been proposed to include some type of scoring/stats/ranking feature to add a 'hook' that will keep players coming back to use the platform regularly and add move value to the membership fee. Sprint #3 is optional as it would go beyond the MVP requirements which are covered by Sprints #1+2.

## Scope of Work

### Development

**SPRINT #1 - Web Application Build: API + Admin Portal**
- ‘Dashboard’ view with relevant reporting o provide executive summary data
- ‘Trainers’ view to search/filter/manage all trainer accounts and their profile data
- ‘Owners’ view to search/filter/manage all owner accounts and their account data
- ‘Animals’ view to search/filter/manage all pet data and their related owners
- ‘Settings’ view to manage general contact information and related organization data
- ‘Users’ view to search/filter/manage all admin users and their account data + roles/permissions
- Custom API to support secure public data transport between passports
- Automated email notifications upon actions TBD
- Postmark API integration for system email processing + tracking
- Google Maps API integration for mapping and geolocation of addresses

**SPRINT #2 - Web Application Build: Trainer Passport**
- LinkedIn style publicly accessible view highlighting trainer credentials, experience, awards, etc.
- Interactive page allows logged in user to edit data in-place and see changes displayed immediately
- Passport can be connected/associated with client company accounts
- Ability to upload media / personalize the page with animal and/or training related photos
- 'Profile' view with tabs to manage trainer passport data
- Unique profile URL sharable via QR Code, including ability for owners to leave reviews
- Secure authentication for trainers to login and access their page/passport/profile

**SPRINT #3 - Web Application Build: K9 Passport**
- K9 profile that can be viewed/shared publicly to store breed, training, health, and boarding related data
- 'Pets' view to search/filter/manage all general pet information including photo(s) of the animal
- 'Training' view to search/filter/manage all training related information entered for the pet
- 'Vaccinations' view to search/filter/manage all vaccinations the animal has received and any future scheduled
- 'Grooming' view to search/filter/manage all grooming appointments, vendors, and services performed
- 'Boarding' view to search/filter/manage all past/future kennel boardings including location, date + time
- 'Invites' view to search/filter/manage all vendor invites to add data to the K9 passport directly
- Automated email reminders to be sent X days prior to a known upcoming vaccination due
- Unique passport URL sharable via QR code, including ability for vendors to provide data when allowed

**SPRINT #4 - Web Application Build: Business Suite**
- ‘Dashboard’ view with relevant reporting o provide executive summary data
- 'Clients’ view to search/filter/manage all relevant client account data
- ‘Prospects’ view to provide ability to store/track potential clients including reporting + email actions
- ‘Sessions’ view to search/filter/manage all training sessions offered, including availability
- ‘Calendar’ view to provide a visual of all the scheduled trainings + availability on a day/week/month view
- 'Boarding' view to provide kennel management including location + dates of availability
- 'Reporting' view to provide general accounting reports over specific periods of time including download/export
- Subscription plan management to offer various features + price points
- Automated email notifications upon successful registration, including reminders
- Reliable Payments API integration for processing online payments via credit card

**SPRINT #5 - Native Application Build: iOs + Android**
- Converting the web application experience for Trainer Passport + K9 Passport into native app experience
- Role-based access provides unique user experiences for Trainer vs Owner
- Trainer passport features available in-app to manage all training related data
- K9 passport features available in-app for owner to manage all pet related data
- QR Code view to share the unique URL for others to access the K9/Trainer Passport
- Deployment to both Google Play + App Store distribution channels
- Push notifications to occur on actions TBD alerting user with message modal + red dot reminder

### Hosting

**Annual Cloud Hosting**
- Twelve (12) months of cloud hosting + uptime support @ app.k9axiom.com (or similar)

### Content

**Testing**
- User, browser, device and automated testing, including deployment of all relevant files to client server
- System health checks built into the platform for monitoring and reporting
- Bug reporting tool available enabled as needed to help troubleshoot any software issues

## Investment

Project to be completed within four (4) months of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Sprint #1 – Web App > API + Admin Portal | 1 | $3,000.00 | $3,000.00 |
| Sprint #2 – Web App > Trainer Passport | 1 | $3,000.00 | $3,000.00 |
| Sprint #3 – Web App > K9 Passport | 1 | $3,000.00 | $3,000.00 |
| Sprint #4 - Web App > Business Suite  | 2 | $3,000.00 | $6,000.00 |
| Sprint #5 – Native App > iOs + Android | 2 | $3,000.00 | $6,000.00 |
| Hosting - Annual Term | 12 | $50.00 | $600.00 |
| Testing - Quality Assurance | 16 | $125.00 | $2,000.00 |
| **Total** | | | **$23,600.00** |

## Payment Milestones

- 20% ($4,720.00) — due to engage project
- 20% ($4,720.00) — due thirty (30) days from project start
- 20% ($4,720.00) — due sixty (60) days from project start
- 20% ($4,720.00) — due ninety (90) days from project start
- 20% ($4,720.00) — due one hundred twenty (120) days from project start

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $175/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
