# Tribble Custom ERP

**Code:** LJ4NVD · https://www.divstrong.com/proposal/LJ4NVD  
**Client:** Ryan Leach · Fresh Move Media · ryan@freshmovemedia.com · www.freshmovemedia.com  
**Status:** viewed  
**Date:** 2026-04-22 · valid until 2026-05-31  
**Total:** $42,650.00

## Overview

We aim is to deliver a modern, cloud-based web application that will serve as an online hub to ultimately manage all aspects of Tribble's operation, including data management, reporting, and role-based access for all employees to utilize the appropriate digital tools. Using an agile development approach, we intend to build the system over a series of 'sprints', each of which will be focused on a specific scope of functionality to be determined during consultative planning meetings with Tribble. 

## Roadmap — The Tribb Roadmap

1. **Strategic Planning** — Requirements Gathering + Site Architecture (2 wk)
2. **Web Application** — Server, API, + Corporate Web Interface (6 wk)
3. **Native Application** — Field App for iOs + Android Devices (4 wk)
4. **QA/Testing** — Quality Assurance, Automated + Human (2 wk)
5. **Launch** — User Acceptance Testing, Live Deployment (2 wk)

## Scope of Work

### Development

**Consulting + Planning**
- Planning meetings with appropriate staff to define the specific scope details to further refine the ‘roadmap’ of all the features to be deployed within each sprint

**Web Application Build > Admin Portal**
- ‘Dashboard’ view to welcome the user and provide an introduction to the intranet tools
- ‘Comms’ view to provide chat and interactive Slack-style communication between team members
- ‘Directory’ view to search/filter/find active employee profiles + contact information for all 160+ employees
- ‘Events’ calendar view to search/filter/navigate a custom events calendar highlighting important dates/details
- ‘Knowledgebase’ library view to provide general company informational resources, guides, videos, etc.
- 'Training' library view to provide a library of resources, job aids, and a 'wizard' to help guide the user to relevant info
- 'Onboarding' view to provide interactive checklist that can be customized for each new hire / role
- 'Notifications' view to search/filter/manage all application notification content
- 'Profile’ view to allow logged in user to manage certain details, avatar, about, etc.
- 'Safety' view to provide OSHA and job specific resources, including access to Safety Score
- ‘Settings’ view to manage general notification preferences and related system settings
- ‘Users’ view to search/filter/manage all portal users and their account data + roles/permissions
- 'Activity Log' to track all user activity / data changes within the digital ecosystem
- Automated email notifications upon successful registration, reminders and alerts TBD
- Postmark API integration for system email processing + tracking

**Native Application Build > Apple (iOs) + Google (Android) Builds**
- ‘Dashboard’ view to welcome the user and provide an introduction to the intranet tools
- ‘Comms’ view to provide chat and interactive Slack-style communication between team members
- ‘Directory’ view to search/filter/find active employee profiles + contact information
- ‘Events’ view to search/filter/navigate a custom events calendar highlighting important dates/details
- 'Onboarding' view to provide interactive checklist of activities to be completed by logged in user
- ‘Knowledgebase’ view to provide access to general document library resources in a mobile friendly format
- 'Training' view to provide access to the training library resources in mobile friendly format
- 'Profile’ view to allow logged in user to manage certain details, avatar, about, etc.
- Push notifications to alert app user with specific messaging based upon actions or admin broadcast

### Hosting

**Annual Cloud Hosting**
- Twelve (12) months of cloud hosting + uptime support @ erp.tribble.com (or similar)
- Installation + configuration of an SSL certificate for data encryption

### Maintenance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server
- Automated health checks, smoke tests, and a 'Status' view for monitoring system uptime/functionality

## Investment

Project to be completed within five (5) months of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Strategy – Consulting + Planning | 24 | $125.00 | $3,000.00 |
| Development –Web Application Build | 160 | $125.00 | $20,000.00 |
| Development –NativeApplication Build | 100 | $125.00 | $12,500.00 |
| Testing – Quality Assurance | 50 | $125.00 | $6,250.00 |
| Hosting | 12 | $75.00 | $900.00 |
| **Total** | | | **$42,650.00** |

## Payment Milestones

- 25% ($10,662.50) — due to engage project
- 25% ($10,662.50) — due upon demonstration of early stage functional prototype
- 25% ($10,662.50) — due upon demonstration of late stage functional prototype
- 25% ($10,662.50) — due upon project completion

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $125/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
