# Pocahontas Parkway AET Conversion Public Communications & Stakeholder Outreach

**Code:** VRWBFY · https://www.divstrong.com/proposal/VRWBFY  
**Client:** Ryan Leach · Fresh Move Media · ryan@freshmovemedia.com · www.freshmovemedia.com  
**Status:** draft  
**Date:** 2026-09-13 · valid until 2026-11-30  
**Total:** $45,000.00

## Overview

Your organization is converting Pocahontas Parkway to All-Electronic Tolling with a cutover targeted for July 1, 2027, and the RFP is explicit that customer-facing communication is one of the principal levers available to move drivers up the conversion funnel — Tier 1 E-ZPass, Tier 2 third-party apps, Tier 3 pay-by-plate — and away from the violator outcome. Equally explicit are the operational demands behind that campaign: a daily dashboard during the launch window covering web traffic, social engagement, Back Office call volumes by topic, complaint sentiment and E-ZPass enrollment counts; weekly written reporting pre-launch and at launch, shifting to monthly during stabilization; numerical KPI targets against a 7.5M-transaction baseline and a 75/13/3/9 payment mix moving toward 85% E-ZPass, 8% pay-by-plate and 7% violators; an attribution approach that has to be invented, because no end-to-end mechanism exists today with the Virginia E-ZPass program or with GoToll, Uproad, NextPass and Peasy. You also need an interactive "Which payment method is right for me?" decision tool, an AET transition page and updated Payment Methods page, and a permanent scam-awareness module on the Parkway site.

divStrong is responding as the technology partner inside a combined team: our marketing agency partner owns strategy, research, brand, creative, paid and earned media, content and stakeholder outreach, while divStrong owns the software — the decision tool, the campaign measurement dashboard, the data source and API integrations to the Back Office System and customer-service platform, the attribution instrumentation, and the scam-monitoring and alerting plumbing that sits under the rapid-response protocol. We deliver that in four two-week sprints at a fixed $3,000 each. Each sprint has a named theme, a bounded scope, and deliverables that are handed over — working software, documented endpoints, a published tool — not activity reports. That cadence gives your team a predictable review point every fourteen days and a clear place to trade scope before anything drifts.

Our team is made up of veteran technologists who have built measurement and integration layers for operators who cannot afford a surprise at go-live, and this project has the profile we do our best work on: real baseline numbers, a hard cutover date, a funnel that can actually be instrumented, and a client that has already thought carefully about what "unexpected bill" costs in call volume and goodwill. We are genuinely excited to build the tool that answers a driver's question in thirty seconds and the dashboard that tells your team, every morning during launch, whether the campaign is working.

## Scope of Work

### Strategy

**Decision Tool Technical Specification** — Specify the "Which payment method is right for me?" tool decision logic, question flow, and related mapping efforts.
-  Decision logic map from trip-frequency and transponder-preference inputs to Tier 1/2/3 recommendations with cost-differential display
-  Technical spec covering hosting options, embed model, accessibility target and analytics event schema

**Scam Threat Response Plan** — Mapping a fraud response feature that states what legitimate Pocahontas communications look like and what they will never ask for, with a verification path a driver can use from a suspicious SMS or email.
- Documentation and process defined to assist the organization in dealing with web-based scams impersonating Pocahontas Parkway or its billing partners 

**Consulting + Planning** — Standing meeting(s) with relevant client staff to obtain direction, feedback and provide recommendations on all application development initiatives throughout the life of the project
- Weekly review of functional sprint progress and overall project status
- Prioritization of project backlog to focus each sprint in accordance with client goals

### Development

**Cloud Platform Architecture + API** — Deployment of a proven, enterprise-grade TALL stack web application delivering fast, reactive interfaces without heavy front-end complexity, and a maintainable codebase built for long-term growth.
- Secure Authentication with hashed credentials, session protection, rate-limited login attempts, and optional two-factor authentication (2FA) to safeguard account access.
- User & Role-Based Permissions to control access to various admin portal resources, so each user sees only the tools and data appropriate to their role.
- Dedicated Cloud Infrastructure with a segregated application server (droplet), separate managed database, and isolated object storage (Spaces) for uploaded files — improving performance, scalability, and fault isolation.
- SSL & Data Encrypting to protect all traffic in transit, plus encryption of sensitive data at rest, ensuring information is protected end to end.
- Backups & Recovery automated with defined retention, enabling fast restoration in the event of data loss.

**Data Source API Integrations** — Integration of third-party data sources TBD such or operational exports, customer-service call/ticket data, web analytics, and paid/organic social APIs — into a single, standardized data store.
- Scheduled ingestion jobs for BOS/operational transaction, payment-mix and violation data with error handling and retry logging
- Customer-service connector mapping ticket and call records to billing-confusion, account-change and 'what is this charge?' topic categories
- Integration details dependent upon client selection  of BOS vendor

**Executive Dashboard** — A single automated dashboard covering all required metrics, refreshed overnight so the daily BO briefing sources from one shared view rather than assembled spreadsheets.
-  Automated daily dashboard: web sessions, social engagement, BO call volume by topic, complaint sentiment, E-ZPass enrollment counts
- KPI target configuration screen so proposed numerical targets can be adjusted and tracked
-  Threshold alerting on call-volume spikes by topic and on negative sentiment surges, routed to named recipients

**Payment Method Decision Tool** — Customer-facing interactive tool that walks a driver through the funnel based on how often they use the Parkway and whether they want a transponder, ending on a clear recommendation with a direct action link.
-  Responsive, WCAG 2.1 AA interactive decision tool with English and Spanish content slots populated from partner-supplied copy
-  Recommendation outcome screens for E-ZPass, third-party app, and pay-by-plate portal with outbound action links and cost comparison
-  Configuration file for third-party app entries so apps can be added or removed at quarterly re-verification without a code change

**Crisis Communication Response Tool** — Automated monitoring for lookalike domains and impersonation signals, wired to the same alerting channel as the dashboard so a scam wave surfaces in hours rather than after press coverage.
-  Lookalike-domain and URL monitoring feed with configurable watch terms and daily digest
-  Alert routing and incident log capturing detection time, first response time and resolution for post-event analysis
-  'Verify a message' page with structured reporting form that logs submissions and alerts the rapid-response group

**Email + SMS Marketing Tool** — Notifications management system allowing direct control over HTML email marketing + SMS messages sent to individuals or groups of customers, including tracking metrics
- 'Emails' view with ability to change core templates + customize content for specific campaigns
- 'SMS' view with ability to manage all SMS messaging content, including the ability to enable/disable for specific actions
- Visual reporting to show open/click/read rates to track engagement

**WCAG 2.1 Accessibility** — We harden everything built across the prior sprints for the traffic spike around cutover and the accessibility obligations of a public-facing government-adjacent asset.
-  WCAG 2.1 AA audit report and remediation for the decision tool and scam module
-  Load-test results and caching/CDN configuration sized for cutover-week traffic on the transition and Payment Methods pages
-  Uptime and error monitoring configured with alert thresholds for the launch window

### Quality Assurance

**Testing**
- Functional testing across modern browsers (Chrome, Firefox, Safari, Edge) and device types (desktop, tablet, mobile) to ensure a consistent experience for every user.
- User Acceptance Testing (UAT) to validate real-world workflows, backed by an automated test suite covering critical application paths for reliability now and through future updates.
- Complete deployment of all application files, database, and configuration to your server environment, including post-launch verification to confirm everything is running as expected in production.

### Implementation

**Handover & Operating Documentation** — All digital assets deployed and/or handed over to the client technical team for implementation
-  Administrator guide for dashboard configuration, KPI targets and third-party app list maintenance
-  Technical runbook covering integrations, credentials rotation, failure modes and recovery steps
-  Source repositories, infrastructure-as-code and deployment documentation transferred to Pocahontas Parkway ownership

## Investment

Project to be completed within four (4) months effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Sprint #1 - Strategy + Planning | 1 | $3,000.00 | $3,000.00 |
| Sprint #2 - Cloud Platform + API | 3 | $3,000.00 | $9,000.00 |
| Sprint #3 — Dashboard + Integrations | 5 | $3,000.00 | $15,000.00 |
| Sprint #4 - Crisis Communications Tool | 3 | $3,000.00 | $9,000.00 |
| Sprint #5 - Email + SMS Marketing Tool | 1 | $3,000.00 | $3,000.00 |
| Sprint #6 - Quality Assurance + Launch | 2 | $3,000.00 | $6,000.00 |
| **Total** | | | **$45,000.00** |

## Payment Milestones

- 25% ($11,250.00) — due to engage project
- 25% ($11,250.00) — due thirty (30) days following project start date
- 25% ($11,250.00) — due thirty (60) days following project start date
- 25% ($11,250.00) — due thirty (90) days following project start date

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
