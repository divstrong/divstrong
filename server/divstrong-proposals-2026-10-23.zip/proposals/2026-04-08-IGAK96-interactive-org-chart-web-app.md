# Interactive Org Chart Web App

**Code:** IGAK96 · https://www.divstrong.com/proposal/IGAK96  
**Client:** Lynne Chaimowitz · City of Pasadena · lchaimowitz@cityofpasadena.net · www.cityofpasadena.net  
**Status:** viewed  
**Date:** 2026-04-08 · valid until 2026-05-31  
**Estimator:** Margaret  
**Total:** $32,500.00

## Overview

We aim is to deliver a modern, cloud-based web application for the City of Pasadena that will serve as an interactive organization chart management + automation tool to help City staff visualize all roles (filled and vacant) - along with additional reporting, sorting, filters and notifications to provide relevant insights designed to assist with resourcing decisions. 

The application includes integration with Tyler Munis to pull real-time employee data to populate org chart with current, accurate staff records. 

## Roadmap — Project Roadmap

1. **Strategic Planning** — Project Kickoff, Early Prototyping (2 wk)
2. **Development** — Build + Deploy Core SaaS Platorm (4 wk)
3. **Integration** — Tyler Munis API Integration (4 wk)
4. **Testing** — Quality Assurance + Project Acceptance (2 wk)
5. **DoIT Review** — Application Approval (4 wk)

## Scope of Work

### Development

**Consulting + Planning**
- Planning meetings with City staff to define a ‘roadmap’ of all the features to be deployed in the initial version of the web application, including data mapping and site architecture documentation
- Application review meetings with City staff to obtain feedback, direction, and confirmation of the implemented features

**Web Application Build > Admin Portal**
- ‘Dashboard’ view with relevant reporting o provide executive summary data
- ‘Organization’ view to search/filter/sort/manage all employee roles in a visual, interactive org chart
- ‘Employees’ view to search/filter/sort/view all employee data pulled in from Tyler Munis, including avatars
- 'Departments' view to search/filter/manage teams, units, groups, etc. for further org classification
- ‘Settings’ view to manage general information and related organization data
- ‘Users’ view to search/filter/manage all admin users and their account data + roles/permissions
- Secure authentication via SSO and/or MFA methods depending on DoIT requirements
- Tyler Munis API integration for pulling data into web application automatically
- Custom public API to provide data to third-party services as needed per integration requirements
- Automated email notifications to desired recipients upon events TBD by City during planning sessions
- Postmark API integration for system email processing + tracking
- Optional 'Activity Log' view to provide visibility and tracking of all user activity within the admin portal
- Google Analytics integration for user engagement reporting

### Hosting

**Annual Cloud Hosting**
- Twelve (12) months of cloud hosting + uptime support @ water.cityofpasadena.gov (or similar)
- Virtual server to include at least 2 GB Memory / 50 GB Disk running LAMP stack on Ubuntu 24.04 

### Maintenance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server
- 'System Health' view will be available in admin portal for monitoring service availability & server status
- Dedicated support ticket system will be provided for issue reporting & feature requests by City staff

## Investment

Project to be completed within four (4) months of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Strategy – Consulting + Planning | 24 | $150.00 | $3,600.00 |
| Development –Web Application Build | 160 | $150.00 | $24,000.00 |
| Hosting – Annual Term | 12 | $75.00 | $900.00 |
| Testing – Quality Assurance | 40 | $100.00 | $4,000.00 |
| **Total** | | | **$32,500.00** |

## Payment Milestones

- 40% ($13,000.00) — due to engage project
- 30% ($9,750.00) — due upon demonstration of functional prototype
- 30% ($9,750.00) — due upon project completion

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $150/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes past due for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.

## Team

- James Doyle — Product Manager
- Margaret Rockwell — Compliance
- Ryan Leach — Operations
