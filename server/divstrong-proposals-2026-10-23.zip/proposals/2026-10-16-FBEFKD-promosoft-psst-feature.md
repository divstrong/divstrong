# PromoSoft PSST Feature

**Code:** FBEFKD · https://www.divstrong.com/proposal/FBEFKD  
**Client:** Doug Mays · PromoSoft · doug@thepromosoft.com · www.thepromosoft.com  
**Status:** converted (accepted 2026-10-19 12:15:46)  
**Date:** 2026-10-16 · valid until 2026-10-31  
**Total:** $2,000.00

## Scope of Work

### Development

**Web Application Enhancements > PSST Sprint** — Updating the PromoSoft web application to include an optional contract printer queue that allows importing of order files and integration of bar code scanners to improve the intake + fulfillment process.
- 'PSST Contract' > new production queue to manage/fulfill contract orders
- Order Import > ability to import and parse a CSV manifest that will populate the day's orders
- Scanning > integration via Bluetooth enabled scanners that will update orders status by scanning/matching tracking #
- Reporting > date sortable summary statistics on the day/week/month/quarter/year's order fulfillment
- Email Notifications > automated emails sent to designated recipients with relevant information as orders are completed
- Order Intake > email parser allowing clients to forward PSST orders to automatic ingestion into the system
- Quality Assurance > automated + user testing to ensure proper functionality

## Investment

Effort to be completed within one (1) week of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Web Development Sprint > AMS Enhancements | 1 | $3,000.00 | $3,000.00 |
| Subtotal | | | $3,000.00 |
| Discount | | | ($1,000.00) |
| **Total** | | | **$2,000.00** |

## Payment Milestones

- 100% ($2,000.00) — Initial deposit to engage project — **paid** 2026-10-19

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.

**Signed by:** Doug Mays
