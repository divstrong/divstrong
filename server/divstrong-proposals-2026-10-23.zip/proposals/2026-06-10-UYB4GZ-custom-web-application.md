# Custom Web Application 

**Code:** UYB4GZ · https://www.divstrong.com/proposal/UYB4GZ  
**Client:** Dani Foley · Let's Mahj Williamsburg · admin@letsmahjwillamsburg.com · www.letsmahjwillamsburg.com  
**Status:** viewed  
**Date:** 2026-06-10 · valid until 2026-07-31  
**Total:** $9,600.00

## Overview

We aim is to deliver a full stack web application that will serve as the backend and administration portal for a native application that will connect Mahjong players with the goal of connecting + playing the game in person at the host venue. Free trials will be offered to new members who will then play a subscription fee to continue using the platform which will be built in a scalable fashion to allow for adding features as the ecosystem expands.

One additional sprint has been proposed to include some type of scoring/stats/ranking feature to add a 'hook' that will keep players coming back to use the platform regularly and add move value to the membership fee. Sprint #3 is optional as it would go beyond the MVP requirements which are covered by Sprints #1+2.

## Scope of Work

### Development

**SPRINT #1 - Web Application Build: API + Admin Portal**
- ‘Dashboard’ view with relevant reporting o provide executive summary data
- ‘Members’ view to search/filter/manage all member accounts and their profile data
- ‘AML Hands’ view to define + manage all the winning hands each year for the American Mahjongg League
- ‘Sessions’ view to search/filter/manage all individual 1:1 sessions offered, including availabiliy
- ‘Calendar’ view to provide a visual of all the various offerings on a day/week/month view
- 'Clients’ view to search/filter/manage all relevant client account data
- ‘Settings’ view to manage general contact information and related organization data
- ‘Users’ view to search/filter/manage all admin users and their account data + roles/permissions
- Automated email notifications upon successful registration, including reminders
- Postmark API integration for system email processing + tracking
- Reliable Payments API integration for processing online payments via credit card
- Google Maps API integration for mapping and geolocation of addresses

**SPRINT #2 - Native iOs + Android Application Build**
- Secure registration + login forms to allow members to join the community
- ‘Profile’ view to update contact, location, billing, and login information
- 'Play' view where member can find available matches in their area with adjustable radius
- 'Matches' view that displays a list of all matches the player has either proposed or attended
- 'Chats' view where the member can engage directly with other members of the community
- 'Results' view where match results can be posted + reviewed
- 'Friends' view where members who have been deemed friends can propose matches directly
- Deployment of native application to both Google Play + App Store for free download
- Automated push notifications to alert the user of confirmed + cancelled matches
- Calendar invites sent automatically to player when matches are accepted

**SPRINT #3 - Native iOs + Android Application Enhanced Features**
- Ability to record match results/scores for historical data and/or public sharing
- Leaderboard and/or ranking system to show where members stand in relation to others using the app
- Specific sprint details to be defined following sprints #1 + #2

### Hosting

**Annual Cloud Hosting**
- Twelve (12) months of cloud hosting + uptime support @ app.letsmahj.com (or similar)

### Content

**Testing**
- User, browser, device and automated testing, including deployment of all relevant files to client server
- System health checks built into the platform for monitoring and reporting
- Bug reporting tool available enabled as needed to help troubleshoot any software issues

## Investment

Project to be completed within two (2) months of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Sprint #1 – Web Application Build | 1 | $3,000.00 | $3,000.00 |
| Sprint #2 –Native Application Build | 1 | $3,000.00 | $3,000.00 |
| Sprint #3 – Native App Enhanced Features | 1 | $3,000.00 | $3,000.00 |
| Hosting – Annual Term | 12 | $50.00 | $600.00 |
| **Total** | | | **$9,600.00** |

## Payment Milestones

- 40% ($3,840.00) — due to engage project
- 30% ($2,880.00) — due upon demonstration of a functional prototype
- 30% ($2,880.00) — due upon project completion

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $175/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
