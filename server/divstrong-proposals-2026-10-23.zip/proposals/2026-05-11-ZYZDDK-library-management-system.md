# Library Management System

**Code:** ZYZDDK · https://www.divstrong.com/proposal/ZYZDDK  
**Client:** Justin Martin · jbmartin@arlingtonva.gov  
**Status:** viewed  
**Date:** 2026-05-11 · valid until 2026-06-30  
**RFP #:** (SPN) NO. N1429  
**Estimator:** Margaret  
**Total:** $133,340.00

## Overview

We are excited by the opportunity to deploy a unified platform for content management, event registration, and space booking that meets the accessibility, reliability, and constituent experience expectations of a first class municipality.

As a boutique SaaS firm that specializes in building civic-focused digital platforms we have a core platform that can be tailored to fit the County's specific needs on a cloud hosted, fully-managed, WCAG 2.1 AA-compliant solution with the flexibility to meet APL's brand  + functional standards.

Our aim is to deliver a solution that exceeds expectations with a fantastic user experience and we are genuinely excited about the prospect of supporting Arlington County's libraries and the communities they serve.

## Roadmap — Project Roadmap

1. **Strategy** — Recurring meetings for continuous feedback & progress (6 wk)
2. **Development** — Agile web application build iterating via sprints (12 wk)
3. **Integration** — API development to connect systems & apps (4 wk)
4. **Testing** — Internal quality assurance, User acceptance testing (2 wk)
5. **Training & Launch** — Documentation and live training to prepare for go live. (4 wk)

## Scope of Work

### Strategy

**Consulting + Planning**
- Planning meetings with County staff to define a ‘roadmap’ of all the features to be deployed in the initial version of the web application, including data mapping and site architecture documentation
- Development review meetings with County staff to obtain feedback, direction, and confirmation of the implemented features

### Design

**Accessible, Branded Patron Experience** — A public-facing interface that meets WCAG 2.1 AA accessibility standards while reflecting Arlington Public Library's visual identity across every patron touchpoint.
- Custom theming aligned to APL brand standards (typography, color, imagery, voice)
- WCAG 2.1 AA conformance with documented accessibility testing and remediation
- Responsive layouts optimized for desktop, tablet, and mobile patrons
- Embeddable widgets for calendars, registration, and room availability

### Development

**Content Management Platform**
- Create, publish, and manage website content using defined templates, customizable fields, and reusable content components that match and can be customized to the APL website branding.
- Allow staff to update public‑facing APL pages without requiring advanced technical skills or coding knowledge.
- Allow staff to assign categories, tags, and metadata to content to support organization, navigation, and searchability.
- Support configurable publishing workflows, including draft, review, approval, and scheduled publication or expiration of content.
- Allow staff to view, modify, and unpublish existing content, including the ability to restore previous versions when available.
- Support staff workflows for creating, editing, duplicating, and organizing content, including internal staff notes and visibility controls.
- Allow staff to create and manage landing pages for locations, departments, services, and program areas.
- Allow staff to manage navigation menus, page hierarchies, and site structure with configurable visibility and access settings.
- Allow staff to store customizable notes or internal documentation associated with content items, visible only to staff.
- Support public‑facing pages that include embedded or linked dynamic content such as events, room availability, or external tools.
- Generate automated notifications to staff for content submissions, approvals, or scheduled publishing actions when applicable.
- Provide reporting on content usage, page views, search terms, and engagement trends.
- Provide public‑facing site search and embeddable widgets suitable for inclusion on APL web pages or external platforms.

**Room Booking Platform** — Ability to manage reservations across 18 spaces in 8 locations, including makerspace equipment and Library of Things items.
- Provide public online booking for defined spaces with configurable availability, blackout dates, lead times, duration limits, and daily/weekly reservation limits. 
- Display detailed information for each space, including capacity limits and photos. 
- Allow patrons to browse available spaces using filters such as room capacity and location, as well as a search function. 
- Allow staff to designate spaces as non-public, visible and reservable for staff only. 
- Allow patrons to make new reservations and manage existing reservations. 
- Allow patrons to make, review, and edit their own reservations and event registrations.
- Allow staff to create, manage and edit all details for spaces.
- Support room equipment inventories, setup and teardown buffer times, and blackout dates by location. 
-  Support parent-child relationships within space reservation setup.
- Allow staff to edit group reservations. 
- Allow staff to add notes in each user's account and display auto-recorded no-shows. 
- Allow costs/charges associated with room bookings. 
- Configurable approval workflows (auto-approval and/or staff approval) by space, user type, or policy. 
- Policy enforcement including required acknowledgements of terms and automated conflict prevention. 
- Support Library of Things reservations and prevent conflicts across locations.
- Support reservation of makerspace equipment. 
- Customizable notifications to staff and patrons for booking confirmations, changes, and cancellations. 
- Administrative reporting on space utilization and booking activity. 
- Provide API that facilitates mobile device room bookings and integrates with APL customized library app or mobile devices. 

**Events & Registration Platform** — Core productivity modules covering event lifecycle management and reservations across 18 spaces in 8 locations, including makerspace equipment and Library of Things items.
- Event calendar with online registration, waitlists, capacity limits, and automated notifications
- Room/space booking with configurable approval workflows, recurring reservations, parent-child relationships, and blackout dates
- iCal/Outlook export, attendance tracking, and reporting dashboards
- Create, publish, and manage events using defined categories, age groups, locations, and customizable fields. 
- Allow patrons to register for events directly from publicly available event listings. 
- Allow staff to assign event categories, age groupings, and apply customizable tags. 
- Support online registrations with configurable capacity limits, automated waitlists, and customizable registration questions. 
- Allow patrons to access detailed event information from listings, including clear indicators when an event has reached capacity. 
- Allow patrons to view, modify and cancel their own event registrations. 
- Support staff workflows for creating, editing, duplicating events, including recurring events, internal staff notes, and visibility controls. 
- Allow staff to plan and manage events, including reserving spaces. 
- Allow staff to view, edit, and cancel existing patron registrations. 
- Allow staff to store customizable notes visible only to staff. 
- Allow staff to record attendance for events. 
- Support public event pages, registration and waitlist functions, event series, presenter information, and cancellation policies. 
- Generate automated email notifications for registration confirmation, reminders, cancellations, and post-event communications. 
- Provide attendance tracking and reporting on registrations, attendance, no-shows, cancellations, and trends. 
- Provide public-facing calendar views and embeddable widgets suitable for inclusion on APL web pages. 

**Integrations, APIs & Security** — Open, standards-based integration with APL's mobile library app and supporting systems, paired with enterprise-grade security and access controls.
- Documented REST API for integration with APL's customized mobile library app
- Optional SSO integration and role-based access control for staff users
- Data encryption in transit and at rest, with PII anonymization after retention period
- Production and sandbox environments for safe configuration and testing

### Content

**Data & Content Migration** — A structured migration of existing content, events, and reservation data from APL's current Springshare platform into the new system with minimal disruption.
- Discovery and mapping of existing Springshare content, calendars, and bookings
- Iterative migration cycles with validation checkpoints and stakeholder review
- Cutover plan with rollback safeguards and go-live readiness checklist
- Post-migration data integrity verification and reconciliation reporting

### Hosting

**Annual Cloud Hosting**
- Twelve (12) months of cloud hosting + uptime support @ library.arlingtonva.gov (or similar)
- Virtual server to include at least 3GB Memory / 250 GB Disk running LAMP stack on Ubuntu 24.04 
- Cloud-hosted SaaS architecture with monitoring, backups, and disaster recovery
- Capacity provisioning sized for ~96,000 patrons and ~98,000 annual attendees
- Routine platform updates, security patching, and performance tuning

### Quality Assurance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server
- 'System Health' view will be available in admin portal for monitoring service availability & server status
- Support ticket system available for reporting bugs/issues

### Implementation

**Training**
- Application training sessions conducted via video conference or in-person with relevant APL staff 
- Training sessions will be recorded as additional guides for future reference

**Documentation**
- API + technical documentation explaining the application stack and general architecture
- User-friendly knowledgebase will also be deployed explaining all key application features in simpler terms

**Deployment**
- Deployment of all application files, data and assets to hosting server
- Deployment of a staging instance to allow for APL testing + review of future enhancements before pushing lvie
- Configuration of an SSL certificate, DNS updates, and site monitoring for uptime + resource management

### Support

**Ticket System**
- Dedicated support ticket system will be provided for issue reporting & feature requests by APL staff
- Support tickets are assigned by priority from Low, Moderate, High, and Critical where the priority determines the order in which it will be addressed.
- Critical and high priority tickets will be addressed same day, typically within a few hours of receipt. 

**Live Support**
- Live, human support available Monday - Friday, 9AM-6PM EST via phone or email.

## Investment

Project to be completed within six (6) months of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Strategy – Consulting + Planning | 80 | $150.00 | $12,000.00 |
| Development –Web Application Build | 480 | $150.00 | $72,000.00 |
| Testing - Quality Assurance | 100 | $100.00 | $10,000.00 |
| Training - Documentation | 50 | $100.00 | $5,000.00 |
| Training - Live/Remote Sessions | 80 | $100.00 | $8,000.00 |
| Maintenance - Annual Support | 160 | $150.00 | $24,000.00 |
| Hosting – Annual Term | 12 | $195.00 | $2,340.00 |
| **Total** | | | **$133,340.00** |

## Payment Milestones

- 25% ($33,335.00) — due to engage project
- 25% ($33,335.00) — due upon demonstration of functional prototype
- 25% ($33,335.00) — due upon project completion
- 25% ($33,335.00) — New Milestone

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $150/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes past due for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.

## References

- Doug Mays · PromoSoft, LLC · 2025
- Jon Laaser · Performance Pickleball · 2024
- Jay Litten · Bridgewater, VA · 2026
