# Custom Web Application

**Code:** J3G21V · https://www.divstrong.com/proposal/J3G21V  
**Client:** J Buckley Warden · DBL Lawyers · buckley@dbllawyers.com · www.dbllawyers.com  
**Status:** draft  
**Date:** 2026-06-19 · valid until 2026-07-31  
**Total:** $7,300.00

## Overview

Our aim is to deliver a full stack web application that will serve as a secure, centralized platform for the firm's internal operations, combining a task manager, an Claude AI-powered chatbot, and document scanning, extracting and review capabilities within a single portal. 

Security and confidentiality are foundational to the build — all client data and documents will be handled within a hardened, access-controlled architecture appropriate for legal work. The platform will be built in a scalable fashion to allow for adding features as the firm's needs and the ecosystem expand.

## Scope of Work

### Development

**SPRINT #1 - Web Application Build: Admin Portal + Task Manager**
- ‘Dashboard’ view with relevant reporting o provide executive summary data
- ‘Clients’ view to search/filter/manage basic client profile data for organization
- ‘Matters’ view to search/filter/manage all individual matters assigned to each client
- 'Tasks’ view to search/filter/manage/assign tasks to individual staff members
- 'Processes' view to search/filter/manage and store process documents organized by matter type
- 'Staff’ view to search/filter/manage all employee account data for accessing the portal
- ‘Settings’ view to manage general contact information and related organization data
- ‘Users’ view to search/filter/manage all admin users and their account data + roles/permissions
- Automated email notifications upon successful task completion / matter resolution, including reminders
- Postmark API integration for system email processing + tracking
- Cloud Console API integration for AI-enabled responses + actions

**SPRINT #2 - Web App Enhancements: Alfred Chatbot + SharePoint Integration**
- Deployment of a ChatBot that will be trained in the persona of J Buckley Warden to be an additional information source made available to portal users
- Deployment of a task product scanning tool that will allow staff to upload/submit their documents for review that will receive automated feedback + grading for performance
- Design + functionality will be guided by the use of existing Alfred prototype
- 'Responses' view where Buckley can provide feedback (star rating +  thumbs up/down) to rank AI response quality for improved output
- Import of existing Claude project + persona settings from prior usage for legal matters
- Automated email notifications sent to Buckley upon certain events / matter types TBD
- Integration of third-party MicroSoft Graph API to connect / reference client documents from Sharepoint storage

**Web Development > HIPAA Data Storage Compliance**
- Encryption in transit — TLS everywhere, HSTS, no plaintext internal hops
- Encryption at rest — encrypted block storage volumes
- Access control — SSH keys only, no password auth, least-privilege DB users, MFA on the parent droplet account
- Network isolation — VPC + Cloud Firewalls so the database + app tier isn't publicly reachable; only the load balancer is exposed
- Audits — application and access logs retained, and critically not logging PHI into application logs, stack traces, or queue payloads
- Backups — encrypted, tested restores, with a documented retention/destruction policy
- Documented Risk Assessment— HIPAA requires the administrative safeguards, not just technical ones

### Hosting

**Annual Cloud Hosting**
- Twelve (12) months of cloud hosting + uptime support @ ai.dbllawers.com (or similar)

### Quality Assurance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server
- System health checks built into the platform for monitoring and reporting
- Bug reporting tool available enabled as needed to help troubleshoot any software issues

## Investment

Project to be completed within two (2) months of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Sprint #1 – Web Application Build | 1 | $3,000.00 | $3,000.00 |
| Web Development > HIPAA Compliance | 4 | $175.00 | $700.00 |
| Sprint #2 – Chatbot + SharePoint Integration | 1 | $3,000.00 | $3,000.00 |
| Hosting - Annual Term | 12 | $50.00 | $600.00 |
| **Total** | | | **$7,300.00** |

## Payment Milestones

- 40% ($2,920.00) — due to engage project
- 30% ($2,190.00) — due upon completion of sprint #1
- 30% ($2,190.00) — due upon completion of sprint #2

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $100/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
