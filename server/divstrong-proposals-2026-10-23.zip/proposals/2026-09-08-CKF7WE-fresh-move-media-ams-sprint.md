# Fresh Move Media AMS Sprint

**Code:** CKF7WE · https://www.divstrong.com/proposal/CKF7WE  
**Client:** Ryan Leach · Fresh Move Media · ryan@freshmovemedia.com · www.freshmovemedia.com  
**Status:** draft  
**Date:** 2026-09-08 · valid until 2026-09-30  
**Total:** $6,000.00

## Overview

Thank you for the opportunity to submit a proposal for your website redesign initiative. We understand that your organization serves a uniquely diverse community — residents, stakeholders, and donors — each with distinct needs, motivations, and journeys through your digital presence. A successful redesign must not only honor the mission of affordable housing advocacy but also clarify brand architecture, elevate resident voices, and create pathways for meaningful engagement across all three audiences.

divStrong is a boutique web development and SaaS studio that specializes in custom, mission-driven websites for organizations serving multiple public audiences. Our approach begins with deep discovery: audience research, stakeholder interviews, user journey mapping, and a clear-eyed brand architecture recommendation to resolve the parent/subsidiary relationship in a way that serves both clarity and strategic goals. From there, we deliver custom, responsive design and CMS-based development grounded in accessibility (WCAG 2.1 AA) and performance best practices.

We recognize that resident stories are the beating heart of your work, and we will build a lightweight, staff-friendly publishing workflow so that new stories can be shared with ease long after launch. Combined with hands-on training, thorough testing, and post-launch support, our goal is to leave your team fully empowered to steward the site with confidence.

We are genuinely excited by the alignment between your mission and our craft, and we look forward to the possibility of partnering with your team on this important work.

## Scope of Work

### Development

**Sprint #1 - Graphic Design Module** — Converting the Figma UI into a set of functional features for both the admin + client to post, review, and provide feedback + approvals on graphic design concepts
- Ability to create Clients + Projects that can  search/sort/filter each view
- Upload graphic design concepts using version control with the ability to switch + compare  various versions
- Client Rejection requires feedback in order to actually reject
- Uploaded design concepts will have interactive canvas allowing direct mark up red ink / comments / etc. for specific feedback
- Sending design concept for client approval can included questions that will require  client to make a specific choice / reply
- Parse image meta from uploaded design file to provide size/depth/related file info metrics
- Integration of ImageMagick to allow download of design files in various image formats
- Automated email + in-app notifications upon acceptance/rejection actions 
- Comments form for providing general comments/feedback on each concept

**Sprint #2 - Script Writing, Shot Notes + Miscellaneous Minor Requests** — Converting sections of the Figma UI into functional views to manage script writing, shot notes, and some miscellaneous change requests across other AMS views.
- Ability to create Clients + Projects that can  search/sort/filter each view
- CRUD ability to add 'Shots' for each reel, describing details needed including optional media upload
- Ability to create + manage shot templates that can be used in future projects
- Internal notes section to capture team comments on each shot/reel
- Single button to convert a shot list into a series of video deliverables assigned to the same client/project
- Script writing status management, ability to directly edit scripts + track changes for audit purposes
- MISC: Invoices > ability to charge manually via the backend using card on file
- MISC: Notifications > need to add ability to Settings > Notifications where admins can manage the content of those notifications 
- MISC: Invoices > download as PDF both public and admin option to create 

### Quality Assurance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server

## Investment

Project to be completed within three (3) weeks of start date, effective upon receipt of initial milestone.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Sprint #1 - Listings Management Plugin | 1 | $3,000.00 | $3,000.00 |
| Sprint #2 - Public Listings Portal | 1 | $3,000.00 | $3,000.00 |
| **Total** | | | **$6,000.00** |

## Payment Milestones

- 25% ($1,500.00) — to engage sprint #1
- 25% ($1,500.00) — for completed sprint #2
- 25% ($1,500.00) — to engage sprint #2
- 25% ($1,500.00) — for completed sprint #2

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
