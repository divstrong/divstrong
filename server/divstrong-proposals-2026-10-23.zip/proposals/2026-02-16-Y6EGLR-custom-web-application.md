# Custom Web Application

**Code:** Y6EGLR · https://www.divstrong.com/proposal/Y6EGLR  
**Client:** Leah Johnson · Second Arrow RVA · secondarrowrva@gmail.com · www.secondarrowrva.com  
**Status:** viewed  
**Date:** 2026-02-16 · valid until 2026-03-31  
**Total:** $15,950.00

## Overview

We aim to deliver a modern, cloud-based web application that will serve as a class management + booking tool serving two distinct customer types - patients & participants - including scheduling, reminders, payments, waivers and more.

## Scope of Work

### Development

**Consulting + Planning**
- Planning meetings with appropriate staff to define a ‘roadmap’ of all the features to be deployed in the initial version of the Second Arrow RVA web application, including data mapping and site architecture documentation

**Web Application Build > Admin Portal**
- ‘Dashboard’ view with relevant reporting o provide executive summary data
- ‘Classes’ view to define + manage all of the individual class data including date, pricing + marketing content
- 'Appointments' view to search/filter/manager all physical therapy appointments
- ‘Instructors’ view to search/filter/manage all instructor related bios, accounts, and their rates + schedules
- ‘Calendar’ view to provide a visual of all the various class offerings + appointments on a day/week/month view
- 'Clients’ view to search/filter/manage all relevant client account data
- 'Payments' view to search/filter all payments captured via the web application for reconciliation
- 'Waivers' view to search/filter/manage all liability waivers, including digital signatures + timestamp
- 'Guests' view to search/filter/manager all guest passes either purchased or included with member plans
- ‘Settings’ view to manage general contact information and related organization data
- ‘Users’ view to search/filter/manage all admin users and their account data + roles/permissions
- Automated email notifications upon successful registration, including reminders
- Postmark API integration for system email processing + tracking
- Reliable Payments API integration for processing online payments via credit card

**Web Application Build > Customer Portal**
- ‘Calendar’ view to provide a visual of all the various class offerings + appointments on a day/week/month view
- ‘Appointments’ view to provide access to view a historical record of all wellness appointments scheduled
- 'Classes' view to provide a historical record of all registered classes
- ‘Profile’ view to provide ability to manage general contact info, stored billing info, and notification settings
- ‘Settings’ view to manage notification preferences and other general settings

### Hosting

**Annual Cloud Hosting**
- Twelve (12) months of cloud hosting + uptime support @ app.secondarrowrva.com (or similar)

### Maintenance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server

## Investment

Project to be completed within three (3) months of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Strategy – Consulting + Planning | 10 | $125.00 | $1,250.00 |
| Development –Web Application Build | 100 | $125.00 | $12,500.00 |
| Testing – Quality Assurance | 16 | $100.00 | $1,600.00 |
| Hosting – Annual Term | 12 | $50.00 | $600.00 |
| **Total** | | | **$15,950.00** |

## Payment Milestones

- 25% ($3,987.50) — due to engage project
- 25% ($3,987.50) — due upon demonstration of early stage functional prototype
- 25% ($3,987.50) — due upon demonstration of late stage functional prototype
- 25% ($3,987.50) — due upon project completion

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $125/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
