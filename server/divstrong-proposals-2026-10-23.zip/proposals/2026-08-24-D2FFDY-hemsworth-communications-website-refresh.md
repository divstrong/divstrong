# Hemsworth Communications Website Refresh

**Code:** D2FFDY · https://www.divstrong.com/proposal/D2FFDY  
**Client:** Michael Jacobs · Hemsworth Communications · michael.jacbos@hemsworthcommunications.com · hemsworthcommunications.com/  
**Status:** draft  
**Date:** 2026-08-24 · valid until 2026-09-30  
**Total:** $3,360.00

## Scope of Work

### Development

**Website Refresh > Content Management System** — Full website refresh including new concept design and migration of all desired existing content into the new build to better represent a South Florida based PR agency in 2026.
- Development of a content management system @ manage.hemsworthcommunications.com
- Creation of new user interface and site design concepts to reflect the style of a hospitality focused PR firm
- Migration of all existing page + blog content from the WordPress instance @ www.hemsworthcommunications.com
- 'Clients' admin tool to manage client records including contact information and logo for prominent display
- 'Employees' admin tool to manage employee records including contact information and avatar images
- 'Locations' admin tool to manage multiple office locations with separate contact information + listings for each
- Deployment of all site files to client server, including installation of SSL certificate
- Contact form to capture general inquiries and send email notifications to site admins
- Lead conversion form to capture potential client information and send email notifications to site admins
- Mobile adaptive design to ensure the site displays properly on handheld and tablet devices
- Postmark API integration for system email management + tracking
- Optional brand refresh to update the logo, color scheme and typography 

## Investment

Effort to be completed within three (3) weeks of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Web Development Sprint > CMS Refresh | 1 | $3,000.00 | $3,000.00 |
| Hosting > Annual Term | 12 | $30.00 | $360.00 |
| **Total** | | | **$3,360.00** |

## Payment Milestones

- 50% ($1,680.00) — Initial deposit to engage project
- 50% ($1,680.00) — Final payment due upon project completion

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
