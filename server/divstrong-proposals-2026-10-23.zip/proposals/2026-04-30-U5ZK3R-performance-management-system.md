# Performance Management System

**Code:** U5ZK3R · https://www.divstrong.com/proposal/U5ZK3R  
**Client:** Adams County Sheriff · rzamora-arroyo@adamscountyco.gov  
**Status:** viewed  
**Date:** 2026-04-30 · valid until 2026-05-31  
**RFP #:** RFP-RZA-2026.541   
**Total:** $84,650.00

## Overview

We aim is to deliver a modern, cloud-based web application for the Adams County CO Sheriff that will serve as an interactive performance management tool to help the Department track employee performance metrics, review and implement career mapping activities, create & manage IDPs, provide surveys and executive level reporting for the various department heads.

With nearly 20 years of experience building custom, SaaS products for organizations across the globe we would be honored to create a best-in-class web application to help the Department achieve it's operational goals. 

Our key differentiator is that we do not maintain any license over the digital products we cerate for our clients, and ownership of the app will transfer to the Department upon completion, requiring only hosting and minimal maintenance to keep active. 

## Roadmap — Project Roadmap

1. **Planning** (2 wk)
2. **Development** (12 wk)
3. **Internal Testing** (3 wk)
4. **Training/UAT** (2 wk)
5. **Compliance** (2 wk)
6. **Launch** (1 wk)
7. **Maintenance** (4 wk)

## Scope of Work

### Development

**Consulting + Planning**
- Planning meetings with Department staff to define a ‘roadmap’ of all the features to be deployed in the initial version of the web application, including data mapping and site architecture documentation
- Application review meetings with Department staff to obtain feedback, direction, and confirmation of the implemented features
- Consultation with HRIS vendor JD Edwards to ensure the integration meets Department expectations

**Web Application Build > Admin Portal**
- ‘Dashboard’ view to provide sortable/exportable executive summary data in role-based visual reports
- ‘Employees’ view to search/filter/sort/view all employee performance data, including goals, IDPs, and reviews
- 'Command' view to provide an interactive visual map of the chain of command, units/teams/departments etc.
- 'IDPs' view to search/filter/manage various individual development plan templates 
- 'Schedule' calendar view to list upcoming checkins, quarterly reviews, and related performance appointments
- 'Actions' view to search/filter/manage action items tasked to individual employees as part of their IDPs and performance reviews
- 'Goals' view to search/filter/manage employee performance goals & metrics on various time scales
- 'Surveys' view to search/filter/manage various surveys including response data/analytics
- 'Objectives' view to search/filter/manage department objectives, standards, priorities, and team goals
- 'Recognition' view where supervisors can showcase/highlight notable employee feats + actions
- 'Activity Log' view to provide visibility and tracking of all user activity within the web application
- ‘Settings’ view to manage general information including user roles + permissions for access
- ‘Users’ view to search/filter/manage all admin users and their account data + roles/permissions
- Secure authentication via SSO and/or MFA methods to comply with County / Department IT requirements
- 'Evaluations' view to search/filter/manage the various types of evaluations offered, including results reporting
- Automated email notifications to desired recipients upon events/actions TBD during planning effort
- JD Edwards API integration to automatically push/pull employee data from HRIS system
- Postmark API integration for system email processing + tracking
- Google Analytics integration for user engagement reporting
- Ensure compliance with Colorado 8 CCR 1501-11 standards
- Ensure WCAG 2.1 AA compatibility to comply with federal accessibility standards
- Installation + configuration of an SSL certificate to ensure data encryption via HTTPS

### Hosting

**Annual Cloud Hosting**
- Twelve (12) months of cloud hosting + server uptime support @ performance.adamssheriffco.gov (or similar)
- Virtual server to include at least 2 GB Memory / 50 GB Disk running LAMP stack on Ubuntu 24.04 

### Maintenance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server
- 'System Health' view will be available in admin portal for monitoring service availability & server status
- Dedicated support ticket system will be provided for issue reporting & feature requests by Department staff

**Training & Documentation**
- Application training sessions conducted via ZOOM/video conference with relevant Department staff 
- API + technical documentation explaining the application stack and general architecture
- User-friendly knowledgebase explaining all key application features 

**Post-Launch Support**
- Dedicated support for the first quarterly review and engagement survey cycle.
- 30-day post-launch support period for bug fixes and minor adjustments.

## Investment

Project to be completed within five (5) months of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Strategy – Consulting + Planning | 50 | $125.00 | $6,250.00 |
| Hosting – Two (2) Year Annual Term | 24 | $75.00 | $1,800.00 |
| Development –Web Application Build | 320 | $150.00 | $48,000.00 |
| Development – IT Compliance | 40 | $150.00 | $6,000.00 |
| Testing – Quality Assurance | 50 | $100.00 | $5,000.00 |
| Training - ZOOM/Live sessions | 40 | $100.00 | $4,000.00 |
| Training - Documentation | 16 | $100.00 | $1,600.00 |
| Maintenance – Two (2) Year Term | 80 | $150.00 | $12,000.00 |
| **Total** | | | **$84,650.00** |

## Payment Milestones

- 25% ($21,162.50) — due to engage project
- 25% ($21,162.50) — due upon demonstration of early stage functional prototype
- 25% ($21,162.50) — due upon demonstration of late stage functional prototype
- 25% ($21,162.50) — due upon project completion

## Change Requests

Any requests for efforts beyond what is described in the ‘Scope of Work’ section of this document must be documented and agreed-upon separately. Approved efforts beyond the scope of this agreement will be billed at a rate of $150/hour.

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes past due for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
10. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.

## Team

- James Doyle — Product Manager
- Margaret Rockwell — Compliance
- Ryan Leach — Operations

## References

- Jay Litten · Bridgewater, VA · 2026
- Doug Mays · PromoSoft, LLC · 2025
- James Crittenden · Fresh Move Media · 2026
