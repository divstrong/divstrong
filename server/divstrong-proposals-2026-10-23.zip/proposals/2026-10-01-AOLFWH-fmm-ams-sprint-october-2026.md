# FMM AMS Sprint > October 2026

**Code:** AOLFWH · https://www.divstrong.com/proposal/AOLFWH  
**Client:** Ryan Leach · Fresh Move Media · ryan@freshmovemedia.com · www.freshmovemedia.com  
**Status:** draft  
**Date:** 2026-10-01 · valid until 2026-10-31  
**Total:** $3,000.00

## Scope of Work

### Development

**Web Application Enhancements > AMS Sprint** — Approved enhancements to the existing Agency Management System (AMS) @ https://portal.freshmovemedia.com
- Invoices > UI + functional enhancements to start accepting payments
- CRM > Quick Actions > Follow Up via Phone Button date + time, add calendar invite to Ryan’s calendar (logged in user, Client + Contact) 
- CRM > Need a custom Project = Sales/Prospects, tasks can also be created for each follow-up with date + time as due date
- CRM > Follow-Up button also adds to activity log
- CRM > Activity Log > delete button for each to remove + confirm modal
- CRM > Create needs services + price options instead of a fixed estimated price field, behave similar to edit > Services setup
- CRM > When entering price, monthly vs one-time price, if months is chosen, add qualifier (Y x Z)
- CRM > Lead Source needs edit ability, currently fixed after creating
- CRM > If lead source = Referral, show other field for selecting client or prospect, along quick add action for prospects to create on the fly
- Tasks > Create calendar item = Location, Google Meet, tees up invites with all client, pick date + time + invitees, select from list of add date + time + send button to create
- Tasks > Search bar needed for clients
- Tasks > Alert > New Task Assigned > Jump to specific task scroll + highlight (similar to @ in chat) 
- Tasks > Pin Projects > pins to top of list, add to three dot action menu
- Tasks > Client Type = Recurring toggle on/off, adds a badge on the project card that states ‘Recurring’
- Tasks > Tasks Due Today > specific tasks clicked should jump to that task detail in list, entire bar is clickable to that detail
- Tasks > Recurring Tasks > once clicked for complete, becomes auto-archived
- Deliverables > Move Create Package down a level to appear on the Client page, not on main one
- Deliverables > Client list > default to alphabetical, + search / auto complete
- Deliverables > Sync with Google Sheets - pull data from source files, see HalperinLegal.com as example - use rows with Order #
- Deliverables > Citations vs Authority Links, see shared templates
- Proposals > Add ADA Compliance section + acceptance signature + initial
- Proposals > Correct numbering and bulleted list display bugs
- Proposals > Need to add monthly option terms as option instead of just number for certain scope items

## Investment

Effort to be completed within one (1) week of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Web Development Sprint > AMS Enhancements | 1 | $3,000.00 | $3,000.00 |
| **Total** | | | **$3,000.00** |

## Payment Milestones

- 50% ($1,500.00) — Initial deposit to engage project
- 50% ($1,500.00) — Final payment due upon project completion

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
