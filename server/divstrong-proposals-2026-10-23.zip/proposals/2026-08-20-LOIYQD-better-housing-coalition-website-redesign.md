# Better Housing Coalition Website Redesign

**Code:** LOIYQD · https://www.divstrong.com/proposal/LOIYQD  
**Client:** Ryan Leach · Fresh Move Media · ryan@freshmovemedia.com · www.freshmovemedia.com  
**Status:** draft  
**Date:** 2026-08-20 · valid until 2026-09-30  
**Total:** $10,250.00

## Overview

Thank you for the opportunity to submit a proposal for your website redesign initiative. We understand that your organization serves a uniquely diverse community — residents, stakeholders, and donors — each with distinct needs, motivations, and journeys through your digital presence. A successful redesign must not only honor the mission of affordable housing advocacy but also clarify brand architecture, elevate resident voices, and create pathways for meaningful engagement across all three audiences.

divStrong is a boutique web development and SaaS studio that specializes in custom, mission-driven websites for organizations serving multiple public audiences. Our approach begins with deep discovery: audience research, stakeholder interviews, user journey mapping, and a clear-eyed brand architecture recommendation to resolve the parent/subsidiary relationship in a way that serves both clarity and strategic goals. From there, we deliver custom, responsive design and CMS-based development grounded in accessibility (WCAG 2.1 AA) and performance best practices.

We recognize that resident stories are the beating heart of your work, and we will build a lightweight, staff-friendly publishing workflow so that new stories can be shared with ease long after launch. Combined with hands-on training, thorough testing, and post-launch support, our goal is to leave your team fully empowered to steward the site with confidence.

We are genuinely excited by the alignment between your mission and our craft, and we look forward to the possibility of partnering with your team on this important work.

## Scope of Work

### Design

**Discovery + Planning** — Engage in a series of discovery, planning, and feedback sessions to ensure the end product aligns with stakeholder goals. Meetings to be held prior to and following each sprint for validation.

### Development

**Sprint #1 - Listings Management Plugin** — Custom development of a WordPress CMS plugin that will allow BHC staff to fully manage listings available on the website
- 'Listings' view allows for management of photos, pricing, location, contact person, description, etc.
- BHC staff with proper access can add, edit, and remove listings depending on their permissions
- Existing listings data migration to seed the new implementation

**Sprint #2 - Public Listings Portal** — Publicly accessible listings that display photos, pricing, and relevant information including the ability to search, sort, filter, save to favorites and share with others.
- Each listing gets its own page with a full photo gallery, complete details, map, and who to contact
- Visitors can search by keyword and narrow results by category, location, or price, then sort however they prefer
- Snapshot and detailed listings page showing photos, pricing, and key details with unique, SEO friendly URLs
- Visitors can save listings to a favorites list to come back to later
- Share listings by link, email, or social media, including snapshots displaying when shared

**Sprint #3 - Eligibility Requirements + Online Application** — Additional tools to allow those interested to validate if they are eligible for a particular property and the ability to submit an application if they meet the criteria.
- A short, guided questionnaire visitors answer to see whether they qualify for a specific property before they invest time in an application
- Instant results — a clear yes, no, or "close but here's what's missing" — with helpful next steps either way
- Qualified visitors move straight into an online application form, with their answers already carried over so nothing is entered twice
- Submitted applications land in the same admin area staff already use, with email notifications and the ability to review, sort, and export them including automated notifications

### Quality Assurance

**Testing**
- User, browser, device and automated testing, including deployment of all site files to client server

## Investment

Project to be completed within six (6) weeks of start date, effective upon receipt of initial milestone.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Sprint #1 - Listings Management Plugin | 1 | $3,000.00 | $3,000.00 |
| Sprint #2 - Public Listings Portal | 1 | $3,000.00 | $3,000.00 |
| Sprint #3 - Eligibility + Application | 1 | $3,000.00 | $3,000.00 |
| Quality Assurance + Testing | 1 | $1,250.00 | $1,250.00 |
| **Total** | | | **$10,250.00** |

## Payment Milestones

- 34% ($3,485.00) — to engage sprint #1
- 33% ($3,382.50) — to engage sprint #2
- 33% ($3,382.50) — to engage sprint #3

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.
