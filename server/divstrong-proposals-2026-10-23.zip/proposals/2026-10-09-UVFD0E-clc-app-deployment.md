# CLC App Deployment

**Code:** UVFD0E · https://www.divstrong.com/proposal/UVFD0E  
**Client:** Ryan Leach · Fresh Move Media · ryan@freshmovemedia.com · www.freshmovemedia.com  
**Status:** converted (accepted 2026-10-19 11:23:11)  
**Date:** 2026-10-09 · valid until 2026-10-31  
**Total:** $5,235.00

## Scope of Work

### Development

**Web Application Build > SaaS Deployment** — Duplication of the existing web application @ app.countylinecollision.com to be customized to match a different company, including data migration and third-party integrations
- Deployment of a secure web application instance @ app.domaintbd.com
- Branding and theme customization to match the company logo, colors and typography
- Data migration to import existing customers, employees, and other relevant information
- DocuSign API integration to import contract templates for dynamic population with customer info
- Postmark API integration for sending/tracking email notifications from the platform
- Twilio API integration for sending/managing SMS notifications
- Reliable Payments API integration for processing payments
- Onboarding + admin portal walkthru with relevant staff

**Web Development Sprint > CLC App Feature Enhancements** — Enhancements and user interface overhaul of the web application @ app.countylinecollision.com to be customized to match the client provided concepts and offer additional features including employee payroll and automation.
- Production Board > enhanced modal form, days on site color coding + labels and improved sublet display   to match the provided Claude concept
- Workload > new view to calculate and visually present how busy each tech is in a given week
- Jobs Board > ability to import EMS files and automatically assign hours to relevant techs to populate their time sheets which are populated by week
- Stage Times > overhaul user interface to match visual style of Claude concept including date filters and ability to exclude/include weekends from time report
- Payroll > admin ability to review, adjust, and mark paid each employee's weekly timecard with week-to-week navigation and reporting over a given date range
- Rules > ability to define + manage the rules of the EMS import and payroll calculations 
- Employee Payroll > each employee has the ability to manage how much money to draw from each job they've worked in a given week, and the ability to 'bank' hours for future draws
- Navigation updated to match the top-level, horizontal approach from Claude concept
- Dark mode to be the default theme choice, updated to  match the Claude concept including light mode alternate

## Investment

Effort to be completed within two (2) weeks of project start date, effective upon receipt of initial deposit.

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Web Development > SaaS Deployment | 1.5 | $1,250.00 | $1,875.00 |
| Web Development Sprint > Feature Enhancements | 1 | $3,000.00 | $3,000.00 |
| Hosting > Server Maintenance + Uptime | 12 | $30.00 | $360.00 |
| **Total** | | | **$5,235.00** |

## Payment Milestones

- 50% ($2,617.50) — Initial deposit to engage project — **paid** 2026-10-19
- 50% ($2,617.50) — Final payment upon project completion, prior to launch

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.

**Signed by:** Ryan Leach
