# City of East Ridge Website Design, CMS & Hosting Services

**Code:** M4CEDK · https://www.divstrong.com/proposal/M4CEDK  
**Client:** Cameron Hobbs-McAllister · City of East Ridge, TN · CMcAllister@eastridgetn.gov · www.eastridgetn.gov  
**Status:** draft  
**Date:** 2026-09-08 · valid until 2026-10-31  
**Total:** $28,700.00

## Overview

We understand that a city's website is far more than just a digital brochure, it is a key touch point between citizens and their local government that can serve as a communication channel for residents as well as an essential tool for transparency, engagement, and service delivery. 

Our Richmond, VA based team of veteran, AI-enabled technologists have carefully reviewed the requirements outlined in the RFP and are excited to present an approach that balances modern design, accessibility, and reliability with the practical needs of a growing Tennessee community.

Our approach centers on delivering a clean, mobile-first, ADA-compliant website powered by a modern content management system that empowers city staff to publish, schedule, and manage data with ease. We will pair this with enterprise-grade cloud hosting featuring redundant infrastructure, off-site backups, and documented disaster recovery — ensuring your site remains available to residents around the clock. 

As a boutique agency with decades of experience building digital products, we pride ourselves on responsive communication, custom-tailored solutions, and long-term partnerships. We look forward to the opportunity to support the City of East Ridge in delivering a website that reflects the character of your community provides real value to both residents and the administration. 

## Roadmap — City of East Ridge, TN Website Refresh

1. **Design** — Sprint 1: Concepts (2 wk)
2. **Development** — Sprint 2: CMS Core (4 wk)
3. **Development** — Sprint 3: Agenda (2 wk)
4. **Development** — Sprint 4: Muni Code (2 wk)
5. **Development** — Sprint 5: Citizen Tool (2 wk)
6. **Development** — Sprint 6: WCAG (2 wk)
7. **Launch** — Sprint 7: Quality Assurance (2 wk)

## Scope of Work

### Design

**Municipal Website User Interface Design** — Modern, mobile-friendly redesign of the public facing municipal website for the City of East Ridge, TN with a focus on usability, accessibility, and consistent branding + messaging across all departments.
- Custom interface design concepts reflecting the city's identity, with responsive layouts for mobile, tablet, and desktop
- Creation of a mood board to define the site theme colors, typography, and tone.
- Graphic design support for iconography, banners, and departmental branding assets

### Development

**Content Management System & Core Features** — User-friendly, modern content management system (CMS) empowering city staff to manage content, calendars, documents, and communications with ease.
- Scheduled content posting and automatic removal, friendly URL management (e.g., /jobs), and site-wide search
- Multiple customizable calendars with ICS export and 'Add to My Calendar' functionality
- Document library with automatic PDF conversion, subscription/notification tools for mailing lists, and integrated social media feeds
- Built-in translation for non-English visitors and analytics dashboards for site statistics and reporting
- Administrative ability to add + manage media - photos, audio, video, etc.
- Resident registration, including profile management and notification preferences
- Secure authentication with role-based access where permissions can be set to allow access
- Social media account integrations: Instagram, Facebook, Twitter/X
- Integration with existing city systems/forms via URL redirect or POST data handoff where applicable
- Google Analytics integration for tracking and visualizing site traffic reports

** Agenda Management System** — Optional enhancement to serve as a management tool for Council and Board packet preparation, publishing, and archiving.
- 'Agenda' view to be added to the administration panel to allow direct management of agenda data

**Municipal Code Lookup Tool** — Optional enhancement to serve as a lookup tool to search the municipal code, including codification of the existing data.
- 'Municipal Code' view to be added to the administration panel to allow direct management of municipal code data
- Public facing /municipal-code view where residents can access + search municipal code data

**Citizen Request Tracker** — Optional enhancement to serve as a Citizen Request Submission and Tracking with web and mobile app, photo uploads, and departmental routing
- Ability for citizens to submit requests with optional attachments via online forms and receive notifications of responses to their requests by city staff
- 'Requests' view to be added to the administration panel for management, assignment, and responding to citizen requests following a support ticket approach

### Hosting

**Cloud Hosting, Redundancy & Disaster Recovery** — Enterprise-grade hosting infrastructure designed for continuous availability, resilience, and rapid recovery.
- 24/7 site availability via redundant cloud infrastructure to ensure content accessibility
- Off-site automated data backups with documented recovery procedures
- Documented disaster recovery plan including redundant hardware, failover architecture, and RTO/RPO targets
- SSL certification, DDoS mitigation, and continuous security monitoring

### Content

**Content Migration & Staff Training** — Structured migration of existing content and hands-on training to ensure your team is confident managing the new platform from day one.
- Audit and migration of existing pages, documents, and media assets from the current site
- Role-based CMS training sessions for administrators, department editors, and content contributors
- Comprehensive documentation, video tutorials, and quick-reference guides

### Maintenance

**Ongoing Support & Maintenance Agreement** — Reliable, responsive post-launch support to keep your website secure, current, and performing at its best.
- 2-hour response target for support requests during 8am–5pm ET business hours
- Routine CMS updates, security patches, and performance monitoring
- Ongoing consultation for future enhancements, including consolidation of related city sites such as Animal Services and Parks & Recreation

## Investment

| Service | Qty | Rate | Amount |
|---|---:|---:|---:|
| Sprint #1 - Interactive Design | 1 | $3,000.00 | $3,000.00 |
| Sprint #2 - Website + Core CMS | 2 | $3,000.00 | $6,000.00 |
| Sprint #3 - Agenda Management System | 1 | $3,000.00 | $3,000.00 |
| Sprint #5 - Citizen Request Tracker | 1 | $3,000.00 | $3,000.00 |
| Sprint #4 - Municipal Code Lookup | 1 | $3,000.00 | $3,000.00 |
| Sprint #6 - Web App > WCAG Compliance | 1 | $3,000.00 | $3,000.00 |
| Sprint #7 - Quality Assurance + Launch | 1 | $3,000.00 | $3,000.00 |
| Hosting - Annual Term | 12 | $75.00 | $900.00 |
| Maintenance - Quarterly Updates | 4 | $950.00 | $3,800.00 |
| **Total** | | | **$28,700.00** |

## Payment Milestones

- 25% ($7,175.00) — initial deposit to engage project
- 25% ($7,175.00) — due upon demonstration of early stage functional prototype
- 25% ($7,175.00) — due upon demonstration of late stage functional prototype
- 25% ($7,175.00) — due upon project completion

## Terms & Conditions

1. Progress payments become due upon completion of established milestones, with the final balance due upon successful delivery of all tasks outlined in ‘Scope of Work’ (SoW. Any deliverables and/or assets due will be transferred to Client upon receipt of the final balance.
2. divStrong will only use materials that are in accordance with copyright laws and Client agrees to only provide material to divStrong for which they have approval, license and/or permission.
3. divStrong shall not be held liable for the accuracy of any information provided by Client.
4. divStrong requires approval of SoW by Client before services will be rendered. Modifications or revisions to the SoW following approval will be billed at the established hourly rate. Client shall receive notice of, and must approve any change requests in order for them to proceed as additional work product.
5. If at any point Client becomes unhappy with the level of service or quality of work received, Client may cancel the project in accordance with the termination clause (#8). A pro-rated refund may be issued for any uncompleted work. ‘Uncompleted Work’ is defined as any work product specified in the SoW including any subsequently approved change requests that have not been substantially completed or submitted for Client review.
6. In the event that any invoice becomes overdue for 30 days or more, divStrong reserves the right to stop work without any further communication.
7. divStrong will not provide Client’s confidential information to any third parties - including, but not limited to names, addresses and trade secrets - without prior authorization from Client. divStrong agrees to take reasonable precautions to prevent unauthorized disclosure of any confidential information provided by Client.
8. This Agreement is effective as of the Effective Date noted herein and shall continue unless terminated; divStrong or Client may terminate this agreement by submitting written notice outlining the reasons for termination. The receiving party will have five (5) days to address the breach and if no resolution is agreed upon will result in the termination of this Agreement. Client will pay divStrong for all services rendered prior to termination.
9. Client agrees not to circumvent divStrong to work independently with divStrong employees, partners, vendors or subcontractors which are only known to client by virtue of the relationship with divStrong, except as expressly agreed to in writing between Client and divStrong.

## Team

- James Doyle — Product Manager
- Margaret Rockwell — Compliance
- Ryan Leach — Operations

## References

- Jay Litten · Bridgewater, VA · 2026
- Doug Mays · PromoSoft, LLC · 2025
- James Crittenden · Fresh Move Media · 2026
