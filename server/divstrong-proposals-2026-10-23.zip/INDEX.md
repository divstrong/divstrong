# Proposal export

Exported October 23, 2026 10:44 AM.

| Code | Date | Client | Project | Status | Total |
|---|---|---|---|---|---|
| BVACFG | 2026-10-23 | Riverside Logistics | Riverside Logistics Custom TMS | draft | $34,500.00 |
| FBEFKD | 2026-10-16 | PromoSoft | PromoSoft PSST Feature | converted | $2,000.00 |
| UVFD0E | 2026-10-09 | Fresh Move Media | CLC App Deployment | converted | $5,235.00 |
| K8RJKR | 2026-10-09 | Warren McCrickard | API Bridge | converted | $4,610.00 |
| AOLFWH | 2026-10-01 | Fresh Move Media | FMM AMS Sprint > October 2026 | draft | $3,000.00 |
| 4PKQBU | 2026-10-01 | Fresh Move Media | Fresh Move Media AMS Sprint | draft | $3,000.00 |
| CMWBW2 | 2026-09-22 | Winners Circle Awards | Annual Web Hosting | converted | $360.00 |
| VRWBFY | 2026-09-13 | Fresh Move Media | Pocahontas Parkway AET Conversion Public Communications & Stakeholder Outreach | draft | $45,000.00 |
| CKF7WE | 2026-09-08 | Fresh Move Media | Fresh Move Media AMS Sprint | draft | $6,000.00 |
| M4CEDK | 2026-09-08 | City of East Ridge, TN | City of East Ridge Website Design, CMS & Hosting Services | draft | $28,700.00 |
| 6Y0K3Y | 2026-09-04 | Fresh Move Media | K9 Axiom Application Build | draft | $23,600.00 |
| D2FFDY | 2026-08-24 | Hemsworth Communications | Hemsworth Communications Website Refresh | draft | $3,360.00 |
| LOIYQD | 2026-08-20 | Fresh Move Media | Better Housing Coalition Website Redesign | draft | $10,250.00 |
| 8MGRD5 | 2026-07-08 | Momma Luna | Custom Web Application (Copy) | viewed | $9,000.00 |
| J3G21V | 2026-06-19 | DBL Lawyers | Custom Web Application | draft | $7,300.00 |
| JSA7AU | 2026-06-10 | Golightly Law | ZOOM Integration + Workshop Enhancements | viewed | $1,925.00 |
| UYB4GZ | 2026-06-10 | Let's Mahj Williamsburg | Custom Web Application  | viewed | $9,600.00 |
| ERQIRT | 2026-06-01 | Golightly Law | CLIO Integration | converted | $725.00 |
| ZYZDDK | 2026-05-11 | Justin Martin | Library Management System | viewed | $133,340.00 |
| U5ZK3R | 2026-04-30 | Adams County Sheriff | Performance Management System | viewed | $84,650.00 |
| LJ4NVD | 2026-04-22 | Fresh Move Media | Tribble Custom ERP | viewed | $42,650.00 |
| XTIOQW | 2026-04-15 | Winners Circle Awards | PromoSoft Chat Feature | converted | $1,600.00 |
| IGAK96 | 2026-04-08 | City of Pasadena | Interactive Org Chart Web App | viewed | $32,500.00 |
| 7M6NOS | 2026-03-01 | PromoSoft, LLC | Supacolor Integration | converted | $1,300.00 |
| FCBLGX | 2026-02-26 | Momma Luna | Custom Web Application | viewed | $19,400.00 |
| FGBNFF | 2026-02-23 | Town of Bridgewater | Zoning Document Management | viewed | $3,400.00 |
| Y6EGLR | 2026-02-16 | Second Arrow RVA | Custom Web Application | viewed | $15,950.00 |
| C0OOYZ | 2026-02-16 | Fresh Move Media | AMS Web App Enhancements | converted | $5,500.00 |
